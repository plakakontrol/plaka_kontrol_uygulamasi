package com.suzuncelebi.plaka_kontrol;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ForgotPasswordActivity extends AppCompatActivity {

    Button gonder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        gonder = findViewById(R.id.gonderbtn);
        gonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ForgotPasswordActivity.this, loginActivity.class);
                startActivity(intent);

                Toast.makeText(ForgotPasswordActivity.this, "Mailinizi Kontrol Edin", Toast.LENGTH_SHORT).show();



            }

        });
    }
}