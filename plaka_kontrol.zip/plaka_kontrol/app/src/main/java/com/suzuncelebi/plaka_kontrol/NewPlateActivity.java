package com.suzuncelebi.plaka_kontrol;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewPlateActivity extends AppCompatActivity {

    TextView txtPlaka;


        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_plate);





                txtPlaka = findViewById(R.id.txtPlate);

                String sonuc = getIntent().getStringExtra("SONUC");
                txtPlaka.setText(sonuc);




                Button kaydet;


            kaydet = findViewById(R.id.SaveBtn);
            kaydet.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(NewPlateActivity.this, ScanPlateActivity.class);
                    startActivity(intent);

                    Toast.makeText(NewPlateActivity.this, "Kayıt Yapıldı", Toast.LENGTH_SHORT).show();



                }

            });
        }
    }