package com.suzuncelebi.plaka_kontrol;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    public Button kayitbtn;
    EditText edt1,edt2,edt3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        initUI();


    }

    private  void initUI()
    {
        edt1=findViewById(R.id.edt1);
        edt2=findViewById(R.id.edt2);
        edt3=findViewById(R.id.edt3);
        kayitbtn = findViewById(R.id.kaydetbtn);
        setListeners();
    }

    private  void setListeners()
    {
        kayitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(isAllFieldsDone())
                {
                    opennextScreen();
                }
                else
                {
                    Toast.makeText(RegisterActivity.this, "Bilgileri doldurunuz..", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    private  boolean isAllFieldsDone()
    {



        boolean c1 =edt1.getText().toString().isEmpty();
        boolean c2=edt2.getText().toString().isEmpty();
        boolean c3=edt3.getText().toString().isEmpty();
        return  (!c1) && (!c2) && (!c3);

    }


    private void opennextScreen()
    {
        Intent kayit = new Intent(RegisterActivity.this, loginActivity.class);
        kayit.putExtra("id",edt1.getText().toString());
        startActivity(kayit);
    }
}