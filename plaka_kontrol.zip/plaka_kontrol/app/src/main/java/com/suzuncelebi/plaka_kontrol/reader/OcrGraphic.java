/*
 * Copyright (C) The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.suzuncelebi.plaka_kontrol.reader;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.Log;

import androidx.appcompat.app.AlertDialog;

import com.google.android.gms.vision.text.TextBlock;
import com.suzuncelebi.plaka_kontrol.ResultActivity;

import java.util.Locale;

/**
 * Graphic instance for rendering TextBlock position, size, and ID within an associated graphic
 * overlay view.
 */
public class OcrGraphic extends GraphicOverlay.Graphic {

    private static final int TEXT_COLOR = Color.YELLOW;

    private static Paint sRectPaint;
    private static Paint sTextPaint;
    private final TextBlock mText;
    public String text;
    Context context;
    Intent myIntent;

    OcrGraphic(GraphicOverlay overlay, TextBlock text) {
        super(overlay);

        mText = text;

        if (sRectPaint == null) {
            sRectPaint = new Paint();
            sRectPaint.setColor(TEXT_COLOR);
            sRectPaint.setStyle(Paint.Style.STROKE);
            sRectPaint.setStrokeWidth(9.0f);
        }

        if (sTextPaint == null) {
            sTextPaint = new Paint();
            sTextPaint.setColor(TEXT_COLOR);
            sTextPaint.setTextSize(30.0f);
        }
        // Redraw the overlay, as this graphic has been added.
        postInvalidate();
    }

    public void saveContext(Context con){
        context = con;
    }
    /**
     * Draws the text block annotations for position, size, and raw value on the supplied canvas.
     */

    boolean isShow =false;
    @Override
    public void draw(Canvas canvas) {
        if (mText == null) {
            return;
        }

        text = mText.getValue();

        if(isPlaka())
        {

            // Draws the bounding box around the TextBlock.
            RectF rect = new RectF(mText.getBoundingBox());
            rect.left = translateX(rect.left);
            rect.top = translateY(rect.top);
            rect.right = translateX(rect.right);
            rect.bottom = translateY(rect.bottom);
            canvas.drawRect(rect, sRectPaint);

            canvas.drawText(text, rect.centerX(), rect.bottom, sTextPaint); //draw on screen
            Log.e("PLAKA " ," "  + text);


            if(!isShow)
            {
                isShow = true ;
                showAlert();

            }




        }
    }



    private  void showAlert()
    {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setTitle(text);
        builder1.setMessage("Plaka Doğru Mu?");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "EVET",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        Intent sonuc =new Intent(context, ResultActivity.class);
                        sonuc.putExtra("SONUC",text);
                        context.startActivity(sonuc);
                        isShow =false;
                        dialog.dismiss();
                    }
                });

        builder1.setNegativeButton(
                "HAYIR",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        isShow =false;
                        dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private  boolean isPlaka()
    {

        if(text.length()>5  && text.length()<=10)
        {

            boolean c1 =text.toLowerCase(new Locale("tr-TR")).startsWith("t");
            boolean c2 =text.toLowerCase(new Locale("tr-TR")).startsWith("r");

            boolean c3 =Character.isDigit(text.charAt(0));
            boolean c4 =Character.isDigit(text.charAt(1));
            boolean c5 =Character.isDigit(text.charAt(2));

            boolean isNumber =c3||c4||c5;

            return c1||c2||isNumber;

        }
        else
        {

            return false;
        }
    }
}
