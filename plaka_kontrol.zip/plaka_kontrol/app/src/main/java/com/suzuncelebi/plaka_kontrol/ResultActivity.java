package com.suzuncelebi.plaka_kontrol;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {


    TextView txtPlaka;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        txtPlaka =findViewById(R.id.txtPlaka);

        String sonuc =getIntent().getStringExtra("SONUC");
        txtPlaka.setText(sonuc);



        Button kayıt;


            kayıt = findViewById(R.id.SavePlate);
            kayıt.setOnClickListener(new View.OnClickListener() {


                @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResultActivity.this, NewPlateActivity.class);
                startActivity(intent);

                Toast.makeText(ResultActivity.this, "Yönlendiriliyorsunuz", Toast.LENGTH_SHORT).show();




                }
            });
        }
    }
