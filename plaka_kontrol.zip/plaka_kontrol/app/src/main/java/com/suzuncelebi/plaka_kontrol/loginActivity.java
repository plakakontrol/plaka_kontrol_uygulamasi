package com.suzuncelebi.plaka_kontrol;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class loginActivity extends AppCompatActivity implements  View.OnClickListener   {

    Button btnRegister,btnForgot,btnLogin;
    EditText ed1, ed2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        initUI();
    }




    private  void initUI()
    {

        ed1 = (EditText) findViewById(R.id.editTextTextPersonName);
        ed2 = (EditText) findViewById(R.id.editTextTextPassword);
        btnLogin = findViewById(R.id.btnGiris);
        btnForgot = findViewById(R.id.btnForgotPass);
        btnRegister = findViewById(R.id.btnRegister);


        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
        btnForgot.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId() ) {
            case R.id.btnGiris:
                doLogin();
                break;
            case R.id.btnForgotPass:

                ekranAc(ForgotPasswordActivity.class);
                break;
            case R.id.btnRegister:
                ekranAc(RegisterActivity.class);
                break;
            default:
                break;
        }
    }

    private  void doLogin()
    {
        if (ed1.getText().toString().equals("s") && ed2.getText().toString().equals("1"))
        {
            Intent i = new Intent(loginActivity.this, ScanPlateActivity.class);
            i.putExtra("id", ed1.getText().toString());
            startActivity(i);
        } else {
            Toast.makeText(getApplicationContext(), "Şifre veya Parola hatalı", Toast.LENGTH_SHORT).show();
        }
    }


    private  void ekranAc(Class<?> cls)
    {
        Intent i = new Intent(loginActivity.this,cls);
        startActivity(i);
    }
}



